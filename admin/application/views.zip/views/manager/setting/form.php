<form action="javascript:void(0);" method="post" id="frm-object">
<div class="row">
	<div class="col-md-12">
  
   	   <div class="card">
       		<div class="card-header">
                   Form Setting
            </div>
            <div class="card-body">
                
                                     
                                 
                                <div class="form-group">
                                    <label>Refferal</label>
                                    <input type="number" class="form-control required" id="refferal" name="refferal" placeholder="Refferal" value="<?=isset($data['refferal'])?$data['refferal']:''?>" />
                                </div>
                                <div class="form-group">
                                    <label>BEP20 Wallet</label>
                                    <input type="text" class="form-control required" id="bep20" name="bep20" placeholder="BEP20" value="<?=isset($data['bep20'])?$data['bep20']:''?>" />
                                </div>
                                <div class="form-group">
                                    <label>TRC20 Wallet</label>
                                    <input type="text" class="form-control required" id="trc20" name="trc20" placeholder="TRC20" value="<?=isset($data['trc20'])?$data['trc20']:''?>" />
                                </div>
                                
                                  
                                
                                <br/>
                                
                                  <div class="form-group">
                                    
                                    <input type="hidden" name="id" value="<?=isset($data['id'])?$data['id']:''?>" id="id" />
                                    <!-- 
                                    <input type="hidden" name="<?=$this->security->get_csrf_token_name()?>" value="<?=$this->security->get_csrf_hash();?>" class="smart-token">
                                    -->
                                    <button type="submit" class="btn btn-primary"><i class="si si-paper-plane "></i> Save</button>
                                    <button type="button" class="btn btn-reset"><i class="fa fa-refresh"></i> Refresh</button>
                                </div>       	
                 </div>
             
            </div>
         </div>
      </div>
                      
                         		   
                         
         
</div>
</form>                        
<script>
$(document).ready(function(){
	$("#frm-object").validate({
		ignore:[],
		onkeyup:false,
		errorClass: 'help-block text-right animated fadeInDown',
		errorElement: 'div',
		errorPlacement: function(error, e) {
			jQuery(e).parents('.form-group').append(error);
		},
		highlight: function(e) {
			jQuery(e).closest('.form-group').removeClass('has-error').addClass('has-error');
			jQuery(e).closest('.help-block').remove();
		},
		success: function(e) {
			jQuery(e).closest('.form-group').removeClass('has-error');
			jQuery(e).closest('.help-block').remove();
		},
		submitHandler:function(){
			var data = new FormData($("#frm-object")[0]);
			var req = postFile('<?=site_url("setting/save")?>',data);
			req.done(function(out){
				if(!out.error)
				{
					smart_success_box(out.message,'#frm-object .block-content');
					document.location.href="<?=site_url('setting')?>";
				}
				else
				{
					smart_error_box(out.message,'#frm-object .block-content');
				}
			});
			return false;
		}
	});
	  
	
});
</script>          